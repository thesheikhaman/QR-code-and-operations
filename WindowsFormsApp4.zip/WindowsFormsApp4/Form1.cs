﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QRCoder;            //For Generating QR CODES
using AForge.Video;       //For Camera 
using AForge.Video.DirectShow;   //For live footage from Camera
using ZXing;                 //fOr Scannnig images from the image Received from Camera
using System.Drawing.Printing;      //for Printing QR on a Paper

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        FilterInfoCollection filterInfoCollection;
        VideoCaptureDevice captureDevice;


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            QRCodeGenerator qr = new QRCodeGenerator();
            QRCodeData data = qr.CreateQrCode(textBox1.Text, QRCodeGenerator.ECCLevel.Q);
            QRCode code = new QRCode(data);
            pictureBox1.Image = code.GetGraphic(5);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            filterInfoCollection = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo filterInfo in filterInfoCollection)
                comboBox1.Items.Add(filterInfo.Name);
            comboBox1.SelectedItem = 0;
        }
        private void button7_Click(object sender, EventArgs e)
        {
            captureDevice= new VideoCaptureDevice(filterInfoCollection[comboBox1.SelectedIndex].MonikerString);
            captureDevice.NewFrame += CaptureDevice_NewFrame; ;
            captureDevice.Start();

        }

        private void CaptureDevice_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            pictureBox1.Image = (Bitmap)eventArgs.Frame.Clone();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (captureDevice.IsRunning)
                    captureDevice.Stop();
            }
            catch (Exception){
            //Do Nothing
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null)
            {
                BarcodeReader barcode = new BarcodeReader();
                Result result = barcode.Decode((Bitmap)pictureBox1.Image);
                if (result != null)
                {
                    textBox2.Text = result.ToString();
                }

            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null)
            {
                BarcodeReader barcode = new BarcodeReader();
                Result result = barcode.Decode((Bitmap)pictureBox1.Image);
                if (result != null)
                {
                    textBox2.Text = result.ToString();
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog() { Filter = @"PNG|*.png" })
            {
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image.Save(saveFileDialog.FileName);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PrintDialog pd = new PrintDialog();

            pd.PrinterSettings = new PrinterSettings();

            if (DialogResult.OK == pd.ShowDialog(this))

            {

                PrintDocument pdoc = new PrintDocument();

                pdoc.PrintPage += new PrintPageEventHandler(pqr);

                pdoc.Print();

            }
        }
        void pqr(object o, PrintPageEventArgs e)
        {

            System.Drawing.Image i = this.pictureBox1.Image;

            Point p = new Point(100, 100);

            e.Graphics.DrawImage(i, p);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = default;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://google.com/search?q=" + textBox1.Text);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (captureDevice.IsRunning)
                captureDevice.Stop();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "png files (*.png)|*.png|All files (*.*)|*.*";
                dialog.InitialDirectory = @"C:\";
                dialog.Title = "Please select an image file to encrypt.";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    String a = dialog.FileName;
                    pictureBox1.Image = Image.FromFile(@a);
                }
            }
            catch (Exception) {
                MessageBox.Show("Image Not supported!;");
                    }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
